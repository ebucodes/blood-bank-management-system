<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "ebucodes_bloodbank";

$conn = mysqli_connect($host, $user, $password, $dbname) or die(mysqli_connect_error($conn));
?>