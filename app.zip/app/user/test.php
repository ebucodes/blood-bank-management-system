<?php
// $dateOfBirth = "15-06-1995";
// $today = date("Y-m-d");
// $diff = date_diff(date_create($dateOfBirth), date_create($today));
// echo 'Your age is ' . $diff->format('%y');
?>
<?php
if (isset($_POST['submit'])) {
    $dob = $_POST['dob'];
    $today = date("Y-m-d");

    $diff = date_diff(date_create($dob), date_create($today));
    $age = $diff->format('%y');
    if ($age > 18) {
        echo 'Your age is ' . $diff->format('%y');
        echo "You are old enough";
    } else {
        echo 'Your age is ' . $diff->format('%y');
        echo 'You are not old enough';
    }
}
?>
<form method="POST">
    <input type="date" name="dob">
    <button type="submit" name="submit">Submit</button>
</form>